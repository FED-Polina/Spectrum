package fedulova.polina303.spectrum.models;

import com.google.gson.annotations.SerializedName;

public class ExperimentDataDTO {

    @SerializedName("created_at")
    String createdAt;

    @SerializedName("tag")
    String tag;

    @SerializedName("note")
    String note;

    @SerializedName("status")
    String status;

    @SerializedName("b64image")
    String b64image;

    @SerializedName("x0")
    Integer x0;

    @SerializedName("y0")
    Integer y0;

    @SerializedName("x1")
    Integer x1;

    @SerializedName("y1")
    Integer y1;

    public String getCreatedAt() {
        return createdAt;
    }

    public String getTag() {
        return tag;
    }

    public String getNote() {
        return note;
    }

    public String getStatus() {
        return status;
    }

    public String getB64image() {
        return b64image;
    }

    public Integer getX0() {
        return x0;
    }

    public Integer getY0() {
        return y0;
    }

    public Integer getX1() {
        return x1;
    }

    public Integer getY1() {
        return y1;
    }
}
