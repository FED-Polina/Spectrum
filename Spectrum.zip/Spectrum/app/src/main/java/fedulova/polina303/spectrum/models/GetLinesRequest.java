package fedulova.polina303.spectrum.models;

import com.google.gson.annotations.SerializedName;

public class GetLinesRequest {
    @SerializedName("atomic_num")
    public Integer atomicNum;
}
