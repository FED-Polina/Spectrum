package fedulova.polina303.spectrum.models;

import com.google.gson.annotations.SerializedName;

public class ExperimentDTO {

    @SerializedName("id")
    Integer experimentId;

    @SerializedName("created_at")
    String createdAt;

    @SerializedName("note")
    String note;

    @SerializedName("status")
    String status;

    public Integer getExperimentId() {
        return experimentId;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getNote() {
        return note;
    }

    public String getStatus() {
        return status;
    }
}
