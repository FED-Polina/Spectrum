package fedulova.polina303.spectrum.ui.adapter;

import fedulova.polina303.spectrum.models.ExperimentDTO;

public interface OnExperimentClickListener {
    void onExperimentClick(ExperimentDTO experiment);
}
