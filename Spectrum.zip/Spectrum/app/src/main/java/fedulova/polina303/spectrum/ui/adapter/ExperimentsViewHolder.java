package fedulova.polina303.spectrum.ui.adapter;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

import fedulova.polina303.spectrum.api.ApiBuilder;
import fedulova.polina303.spectrum.api.SpectreAPI;
import fedulova.polina303.spectrum.databinding.ItemExperimentBinding;
import fedulova.polina303.spectrum.models.ExperimentDTO;
import fedulova.polina303.spectrum.models.ExperimentDataDTO;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ExperimentsViewHolder extends RecyclerView.ViewHolder {

    private ItemExperimentBinding itemBinding;
    private OnExperimentClickListener listener;
    private SpectreAPI api = ApiBuilder.getAPI();
    private String status = "";
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable runnable;

    public ExperimentsViewHolder(@NonNull View itemView, OnExperimentClickListener listener) {
        super(itemView);
        itemBinding = ItemExperimentBinding.bind(itemView);
        this.listener = listener;
    }

    @SuppressLint("DefaultLocale")
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void bind(ExperimentDTO experiment) {
        runnable = () -> {
            if (!status.equals("done")) {
                api.getExperimentStatus(experiment.getExperimentId()).enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(Call<String> call, Response<String> response) {
                        status = response.body();
                        if (!status.equals("done")) {
                            itemBinding.tvCurrentTime.setVisibility(View.VISIBLE);
                            itemBinding.tvCurrentTime.setText(
                                    String.format(
                                            "%02d.%02d.%04d %02d:%02d:%02d",
                                            LocalDateTime.now().getDayOfMonth(),
                                            LocalDateTime.now().getMonthValue(),
                                            LocalDateTime.now().getYear(),
                                            LocalDateTime.now().getHour(),
                                            LocalDateTime.now().getMinute(),
                                            LocalDateTime.now().getSecond()
                                    )
                            );
                        } else {

                            itemBinding.tvCurrentTime.setVisibility(View.GONE);
                        }
                        handler.postDelayed(runnable, 1000);
                    }

                    @Override
                    public void onFailure(Call<String> call, Throwable t) {
                    }
                });
            }
        };

        if (!experiment.getStatus().equals("done")) {
            handler.postDelayed(runnable, 1000);
        }

        LocalDateTime dateTime = LocalDateTime.parse(experiment.getCreatedAt().substring(0, experiment.getCreatedAt().lastIndexOf('.')), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
        itemBinding.tvTitle.setText(experiment.getNote());
        itemBinding.tvStatus.setText(experiment.getStatus());
        itemBinding.tvCreateTime.setText(
                String.format(
                        "%02d.%02d.%04d %02d:%02d:%02d",
                        dateTime.getDayOfMonth(),
                        dateTime.getMonthValue(),
                        dateTime.getYear(),
                        dateTime.getHour(),
                        dateTime.getMinute(),
                        dateTime.getSecond()
                )
        );

        api.getExperimentData(experiment.getExperimentId()).enqueue(new Callback<List<ExperimentDataDTO>>() {
            @Override
            public void onResponse(Call<List<ExperimentDataDTO>> call, Response<List<ExperimentDataDTO>> response) {
                byte[] img = Base64.decode(response.body().get(0).getB64image(), Base64.DEFAULT);
                Bitmap image = BitmapFactory.decodeByteArray(img, 0, img.length);

                Glide.with(itemView).load(image).into(itemBinding.ivImage);
            }

            @Override
            public void onFailure(Call<List<ExperimentDataDTO>> call, Throwable t) {

            }
        });

            itemBinding.getRoot().setOnClickListener(v -> {
                if(experiment.getStatus().equals("done")) {
                    listener.onExperimentClick(experiment);
                }

            });
    }
}
