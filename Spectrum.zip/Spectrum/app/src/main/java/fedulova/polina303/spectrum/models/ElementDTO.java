package fedulova.polina303.spectrum.models;

import com.google.gson.annotations.SerializedName;

public class ElementDTO {
    @SerializedName("atomic_num")
    public Integer atomicNum;
    @SerializedName("full_name")
    public String full_name;

    public ElementDTO(Integer atomicNum, String full_name) {
        this.atomicNum = atomicNum;
        this.full_name = full_name;
    }

    @Override
    public String toString() {
        return full_name;
    }
}
