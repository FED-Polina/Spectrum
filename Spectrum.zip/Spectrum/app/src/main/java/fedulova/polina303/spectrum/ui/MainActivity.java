package fedulova.polina303.spectrum.ui;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ArrayAdapter;

import com.bumptech.glide.Glide;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import fedulova.polina303.spectrum.api.ApiBuilder;
import fedulova.polina303.spectrum.api.SpectreAPI;
import fedulova.polina303.spectrum.database.ExperimentsDatabase;
import fedulova.polina303.spectrum.databinding.ActivityMainBinding;
import fedulova.polina303.spectrum.models.ElementDTO;
import fedulova.polina303.spectrum.models.ExperimentDataDTO;
import fedulova.polina303.spectrum.models.LuminanceDTO;
import fedulova.polina303.spectrum.models.WaveDTO;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private SpectreAPI api = ApiBuilder.getAPI();

    ArrayAdapter<ElementDTO> adp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ExperimentsDatabase db = new ExperimentsDatabase(this);

        adp = new ArrayAdapter<ElementDTO>(this, android.R.layout.simple_list_item_1);

        Integer experimentId = getIntent().getIntExtra("EXPERIMENT_ID", -1);

        api.getExperimentData(experimentId).enqueue(new Callback<List<ExperimentDataDTO>>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @SuppressLint("DefaultLocale")
            @Override
            public void onResponse(Call<List<ExperimentDataDTO>> call, Response<List<ExperimentDataDTO>> response) {
                byte[] img = Base64.decode(response.body().get(0).getB64image(), Base64.DEFAULT);
                Bitmap image = BitmapFactory.decodeByteArray(img, 0, img.length);

                Glide.with(binding.getRoot()).load(image).into(binding.ivExperimentImage);

                binding.tvExperimentTitle.setText(response.body().get(0).getNote());
                LocalDateTime dateTime = LocalDateTime.parse(response.body().get(0).getCreatedAt().substring(0, response.body().get(0).getCreatedAt().lastIndexOf('.')), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
                binding.tvExperimentTime.setText(
                        String.format(
                                "%02d.%02d.%04d %02d:%02d:%02d",
                                dateTime.getDayOfMonth(),
                                dateTime.getMonthValue(),
                                dateTime.getYear(),
                                dateTime.getHour(),
                                dateTime.getMinute(),
                                dateTime.getSecond()
                        )
                );
            }

            @Override
            public void onFailure(Call<List<ExperimentDataDTO>> call, Throwable t) {

            }
        });

        api.getLines(db.getAtomFromExperiment(experimentId).atomicNum).enqueue(new Callback<List<WaveDTO>>() {
            @Override
            public void onResponse(Call<List<WaveDTO>> call, Response<List<WaveDTO>> response) {
                binding.spectraView.refreshSpectre(response.body());
                binding.tvSelectedElement.setText("Element: " + db.getAtomFromExperiment(experimentId).full_name);
            }

            @Override
            public void onFailure(Call<List<WaveDTO>> call, Throwable t) {}
        });

        api.getLuminanceProfile(experimentId).enqueue(new Callback<List<LuminanceDTO>>() {
            @Override
            public void onResponse(Call<List<LuminanceDTO>> call, Response<List<LuminanceDTO>> response) {
                binding.spectraView.refreshGraph(response.body());
            }

            @Override
            public void onFailure(Call<List<LuminanceDTO>> call, Throwable t) {

            }
        });

        binding.btnPlus.setOnClickListener(v -> {
            float wlen_center = (binding.spectraView.wlen_max + binding.spectraView.wlen_min) / 2.0f;
            float wlen_dist = wlen_center - binding.spectraView.wlen_min;
            float zoom_percent = 0.1f;
            binding.spectraView.wlen_min += wlen_dist * zoom_percent;
            binding.spectraView.wlen_max -= wlen_dist * zoom_percent;
            binding.spectraView.have_background = false;
            binding.spectraView.invalidate();
        });

        binding.btnMinus.setOnClickListener(v -> {
            float wlen_center = (binding.spectraView.wlen_max + binding.spectraView.wlen_min) / 2.0f;
            float wlen_dist = wlen_center - binding.spectraView.wlen_min;
            float zoom_percent = 0.1f;
            binding.spectraView.wlen_min -= wlen_dist * zoom_percent;
            binding.spectraView.wlen_max += wlen_dist * zoom_percent;
            binding.spectraView.have_background = false;
            binding.spectraView.invalidate();
        });
    }
}