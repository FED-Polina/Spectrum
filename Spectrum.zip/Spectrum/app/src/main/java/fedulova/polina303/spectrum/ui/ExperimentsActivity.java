package fedulova.polina303.spectrum.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import java.util.List;

import fedulova.polina303.spectrum.api.ApiBuilder;
import fedulova.polina303.spectrum.api.SpectreAPI;
import fedulova.polina303.spectrum.database.ExperimentsDatabase;
import fedulova.polina303.spectrum.ui.adapter.ExperimentsAdapter;
import fedulova.polina303.spectrum.databinding.ActivityExperimentsBinding;
import fedulova.polina303.spectrum.models.ExperimentDTO;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ExperimentsActivity extends AppCompatActivity {
    private ActivityExperimentsBinding binding;
    private ExperimentsAdapter adapter;
    private ArrayAdapter<String> tagsAdapter;
    private SpectreAPI api = ApiBuilder.getAPI();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityExperimentsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        ExperimentsDatabase db = new ExperimentsDatabase(this);
//        db.fillDatabase();

        adapter = new ExperimentsAdapter(experiment -> {
                Intent i = new Intent(this, MainActivity.class);
                i.putExtra("EXPERIMENT_ID", experiment.getExperimentId());
                startActivity(i);
        });
        tagsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);

        binding.rvExperiments.setAdapter(adapter);

        api.getTags().enqueue(new Callback<List<String>>() {
            @Override
            public void onResponse(Call<List<String>> call, Response<List<String>> response) {
                tagsAdapter.addAll(response.body());
                binding.spinnerTags.setAdapter(tagsAdapter);

                api.getExperiments((String) binding.spinnerTags.getSelectedItem()).enqueue(new Callback<List<ExperimentDTO>>() {
                    @Override
                    public void onResponse(Call<List<ExperimentDTO>> call, Response<List<ExperimentDTO>> response) {
                        adapter.submitList(response.body());
                    }

                    @Override
                    public void onFailure(Call<List<ExperimentDTO>> call, Throwable t) {

                    }
                });
            }

            @Override
            public void onFailure(Call<List<String>> call, Throwable t) {

            }
        });

        binding.spinnerTags.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                api.getExperiments((String) binding.spinnerTags.getSelectedItem()).enqueue(new Callback<List<ExperimentDTO>>() {
                    @Override
                    public void onResponse(Call<List<ExperimentDTO>> call, Response<List<ExperimentDTO>> response) {
                        adapter.submitList(response.body());
                    }

                    @Override
                    public void onFailure(Call<List<ExperimentDTO>> call, Throwable t) {

                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}