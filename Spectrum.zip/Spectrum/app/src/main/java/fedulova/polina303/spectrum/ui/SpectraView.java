package fedulova.polina303.spectrum.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import fedulova.polina303.spectrum.api.ApiBuilder;
import fedulova.polina303.spectrum.api.SpectreAPI;
import fedulova.polina303.spectrum.models.LuminanceDTO;
import fedulova.polina303.spectrum.models.ShortWaveDTO;
import fedulova.polina303.spectrum.models.WaveDTO;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SpectraView extends SurfaceView {
    private ArrayList<WaveDTO> lines = new ArrayList<>();
    private ArrayList<LuminanceDTO> luminance = new ArrayList<>();
    private SpectreAPI api = ApiBuilder.getAPI();

    boolean have_background = false;

    float wlen_min = 380.0f;
    float wlen_max = 780.0f;

    List<Integer> marks = Arrays.asList(380, 440, 490, 510, 580, 645, 780);

    private List<ShortWaveDTO> rgb = new ArrayList<>();

    public SpectraView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
    }

    private void download_background(int steps) {
        api.getRgbRange(wlen_min, wlen_max, steps).enqueue(new Callback<List<ShortWaveDTO>>() {
            @Override
            public void onResponse(Call<List<ShortWaveDTO>> call, Response<List<ShortWaveDTO>> response) {
                rgb = response.body();
                have_background = true;
                invalidate();
            }

            @Override
            public void onFailure(Call<List<ShortWaveDTO>> call, Throwable t) {
            }
        });
    }

    float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    float unlerp(float x, float x0, float x1) {
        return (x - x0) / (x1 - x0);
    }

    float map(float x, float x0, float x1, float a, float b) {
        float t = unlerp(x, x0, x1);
        return lerp(a, b, t);
    }

    float last_x = 0.0f;
    int img_w;
    boolean moving = false;

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                last_x = event.getX();
                moving = true;
                return true;
            case MotionEvent.ACTION_UP:
                moving = false;
                have_background = false;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                float new_x = event.getX();
                float delta_x = new_x - last_x;
                float delta_nm = wlen_max - wlen_min;
                float nm_per_pixel = delta_nm / img_w;
                wlen_min -= delta_x * nm_per_pixel;
                wlen_max -= delta_x * nm_per_pixel;
                last_x = event.getX();
                invalidate();
                return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = canvas.getWidth();
        int h = canvas.getHeight();

        img_w = w;

        int luminanceNum = 1;
        int lastLum = 0;

        if (!luminance.isEmpty() && !rgb.isEmpty()) {
            for (int j = 1; j < luminance.size(); j++) {
                if (rgb.get(0).wavelength.intValue() < luminance.get(j).getNanometers().intValue()) {
                    luminanceNum = j;
                    break;
                }
            }
        }

        canvas.drawColor(Color.BLACK);
        if (!have_background) {
            download_background(w);
        } else {
            if (moving == false)
                for (int i = 0; i < rgb.size(); i++) {


                    canvas.drawLine(i, 0, i, h, rgb.get(i).getPaint());

                    Paint markPaint = new Paint();
                    markPaint.setTextSize(40);
                    markPaint.setColor(Color.WHITE);
                    if (marks.contains(rgb.get(i).wavelength.intValue())) {
                        canvas.drawText(
                                String.valueOf(rgb.get(i).wavelength.intValue()),
                                i,
                                h - 20,
                                markPaint
                        );
                    }

                    Paint luminancePaint = new Paint();
                    luminancePaint.setColor(Color.RED);
                    luminancePaint.setStrokeWidth(5);

                    if (luminanceNum < luminance.size()) {
                        Log.d("LUMINANCE", i + " --- " + rgb.get(i).wavelength.intValue() + " --- " + luminance.get(luminanceNum).getNanometers().intValue());
                        if (rgb.get(i).wavelength.intValue() == luminance.get(luminanceNum).getNanometers().intValue()) {
                            canvas.drawLine(lastLum, h * luminance.get(luminanceNum - 1).getLuminance(), i, h * luminance.get(luminanceNum).getLuminance(), luminancePaint);

                            lastLum = i;
                            luminanceNum++;
                        }
                    }

                }
        }

        for (WaveDTO wave : lines) {
            float x = map(wave.wavelength, wlen_min, wlen_max, 0, w - 1);
            canvas.drawLine(x, 0, x, h, wave.getPaint());
        }
    }

    public void refreshSpectre(List<WaveDTO> newSpectre) {
        lines.clear();
        lines.addAll(newSpectre);

        invalidate();
    }

    public void refreshGraph(List<LuminanceDTO> newLuminance) {
        luminance.clear();
        luminance.addAll(newLuminance);

        invalidate();
    }
}
