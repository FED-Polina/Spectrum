package fedulova.polina303.spectrum.api;

import java.util.List;

import fedulova.polina303.spectrum.models.ElementDTO;
import fedulova.polina303.spectrum.models.ExperimentDTO;
import fedulova.polina303.spectrum.models.ExperimentDataDTO;
import fedulova.polina303.spectrum.models.LuminanceDTO;
import fedulova.polina303.spectrum.models.ShortWaveDTO;
import fedulova.polina303.spectrum.models.WaveDTO;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface SpectreAPI {

    @GET("/rpc/get_lines")
    Call<List<WaveDTO>> getLines(
            @Query("atomic_num") Integer atomicNum
    );

    @GET("/rpc/get_elements")
    Call<List<ElementDTO>> getElements();

    @GET("/rpc/nm_to_rgb_range")
    Call<List<ShortWaveDTO>> getRgbRange(
            @Query("nm_from") Float nm_from,
            @Query("nm_to") Float nm_to,
            @Query("steps") Integer steps
    );

    @GET("/rpc/get_tags")
    Call<List<String>> getTags();

    @GET("/rpc/get_experiments")
    Call<List<ExperimentDTO>> getExperiments(
            @Query("tagname") String tag
    );

    @GET("/rpc/get_experiment_data")
    Call<List<ExperimentDataDTO>> getExperimentData(
            @Query("experiment") Integer experiment
    );

    @GET("/rpc/get_luminance_profile")
    Call<List<LuminanceDTO>> getLuminanceProfile(
            @Query("experiment_id") Integer experimentId
    );

    @GET("/rpc/get_status")
    Call<String> getExperimentStatus(
            @Query("experiment") Integer experiment
    );

}
