package fedulova.polina303.spectrum.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.List;

import fedulova.polina303.spectrum.api.ApiBuilder;
import fedulova.polina303.spectrum.api.SpectreAPI;
import fedulova.polina303.spectrum.models.ElementDTO;
import fedulova.polina303.spectrum.models.ExperimentDTO;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ExperimentsDatabase extends SQLiteOpenHelper {

    private SpectreAPI api = ApiBuilder.getAPI();

    public ExperimentsDatabase(@Nullable Context context) {
        super(context, "experiment.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "" +
                "CREATE TABLE IF NOT EXISTS experiments (" +
                "experimentId INTEGER," +
                "atomicNum INTEGER," +
                "atomName TEXT" +
                ")";

        db.execSQL(sql);
    }

    public void fillDatabase() {
        final int[] atomicNum = {1};

        api.getElements().enqueue(new Callback<List<ElementDTO>>() {
            @Override
            public void onResponse(Call<List<ElementDTO>> call, Response<List<ElementDTO>> elementsResponse) {
                api.getTags().enqueue(new Callback<List<String>>() {
                    @Override
                    public void onResponse(Call<List<String>> call, Response<List<String>> tagResponse) {
                        for (String tag : tagResponse.body()) {
                            api.getExperiments(tag).enqueue(new Callback<List<ExperimentDTO>>() {
                                @Override
                                public void onResponse(Call<List<ExperimentDTO>> call, Response<List<ExperimentDTO>> response) {
                                    for (ExperimentDTO experiment: response.body()) {
                                        String insertSql = "INSERT INTO experiments VALUES (" + experiment.getExperimentId() + ", " + elementsResponse.body().get(atomicNum[0]).atomicNum + ", '" + elementsResponse.body().get(atomicNum[0]).full_name + "' );";
                                        getWritableDatabase().execSQL(insertSql);

                                        if (atomicNum[0] + 1 == elementsResponse.body().size()) {
                                            atomicNum[0] = 0;
                                        } else {
                                            atomicNum[0]++;
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(Call<List<ExperimentDTO>> call, Throwable t) {}
                            });
                        }
                    }

                    @Override
                    public void onFailure(Call<List<String>> call, Throwable t) {}
                });
            }

            @Override
            public void onFailure(Call<List<ElementDTO>> call, Throwable t) {}
        });
    }

    public ElementDTO getAtomFromExperiment(Integer experimentId) {
        String sql = "SELECT * FROM experiments WHERE experimentId = " + experimentId + " ;";
//        String sql = "SELECT * FROM experiments;";

        Cursor cur = getReadableDatabase().rawQuery(sql, null);
//        if (cur.moveToFirst()) {
//            while (cur.moveToNext()) {
//                Log.d("DATABASE", String.valueOf(cur.getInt(0)) + " ___ " +  String.valueOf(cur.getInt(1))+ " ___ " +  cur.getString(2));
//            }
//        }

        cur.moveToFirst();
        return new ElementDTO(
                cur.getInt(1),
                cur.getString(2)
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}
}
