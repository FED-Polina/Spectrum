package fedulova.polina303.spectrum.ui.adapter;

import android.os.Build;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import java.util.Objects;

import fedulova.polina303.spectrum.R;
import fedulova.polina303.spectrum.models.ExperimentDTO;

public class ExperimentsAdapter extends ListAdapter<ExperimentDTO, ExperimentsViewHolder> {
    private OnExperimentClickListener listener;

    public ExperimentsAdapter(OnExperimentClickListener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    //создание элементов-экспериментов
    public ExperimentsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ExperimentsViewHolder(
                LayoutInflater.from(parent.getContext()).inflate(R.layout.item_experiment, parent, false),
                listener
        );
    }

    @Override
    public void onBindViewHolder(@NonNull ExperimentsViewHolder holder, int position) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            holder.bind(getItem(position));
        }
    }

    //утилита для сравнения объектов
    public static final DiffUtil.ItemCallback<ExperimentDTO> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<ExperimentDTO>() {
                @Override
                public boolean areItemsTheSame(
                        @NonNull ExperimentDTO oldUser, @NonNull ExperimentDTO newUser) {
                    // User properties may have changed if reloaded from the DB, but ID is fixed
                    return Objects.equals(oldUser.getExperimentId(), newUser.getExperimentId());
                }

                @Override
                public boolean areContentsTheSame(
                        @NonNull ExperimentDTO oldUser, @NonNull ExperimentDTO newUser) {
                    // NOTE: if you use equals, your object must properly override Object#equals()
                    // Incorrectly returning false here will result in too many animations.
                    return Objects.equals(oldUser.getExperimentId(), newUser.getExperimentId())
                            && Objects.equals(oldUser.getCreatedAt(), newUser.getCreatedAt())
                            && Objects.equals(oldUser.getNote(), newUser.getNote())
                            && Objects.equals(oldUser.getStatus(), newUser.getStatus());
                }
            };
}
