package fedulova.polina303.spectrum.models;

import android.graphics.Paint;

import com.google.gson.annotations.SerializedName;

public class ShortWaveDTO {
    @SerializedName("wavelength")
    public Float wavelength;
    @SerializedName("red")
    public Double red;
    @SerializedName("green")
    public Double green;
    @SerializedName("blue")
    public Double blue;

    public Paint getPaint() {
        Paint p = new Paint();
        p.setARGB(255, (int) (red * 255.0 / 4), (int) (green * 255.0 / 4), (int) (blue * 255.0 / 4));
        return p;
    }
}
