package fedulova.polina303.spectrum.models;

import com.google.gson.annotations.SerializedName;

public class LuminanceDTO {
    @SerializedName("nm")
    Float nanometers;

    @SerializedName("lum")
    Float luminance;

    public Float getNanometers() {
        return nanometers;
    }

    public Float getLuminance() {
        return luminance;
    }
}
